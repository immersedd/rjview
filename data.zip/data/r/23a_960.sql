SELECT
  MIN(kt.kind) AS movie_kind,
  MIN(t.title) AS complete_us_internet_movie
FROM complete_cast AS cc, comp_cast_type AS cct1, company_type AS ct, info_type AS it1, keyword AS k, kind_type AS kt, movie_companies AS mc, movie_info AS mi, movie_keyword AS mk, title AS t, mv960
WHERE
  (
    t.id = mc.movie_id
  )
  AND (
    mc.movie_id = mk.movie_id
  )
  AND (
    t.id = cc.movie_id
  )
  AND (
    cc.status_id = cct1.id
  )
  AND (
    t.production_year > 2000
  )
  AND (
    kt.id = t.kind_id
  )
  AND (
    mi.movie_id = t.id
  )
  AND (
    (
      NOT mi.info IS NULL
    )
    AND (
      mi.note LIKE '%internet%'
    )
    AND (
      (
        mi.info LIKE 'USA:% 199%'
      ) OR (
        mi.info LIKE 'USA:% 200%'
      )
    )
  )
  AND (
    mk.movie_id = t.id
  )
  AND (
    mv960.company_name_id = mc.company_id
  )
  AND (
    ct.id = mc.company_type_id
  )
  AND (
    it1.id = mi.info_type_id
  )
  AND (
    it1.info = 'release dates'
  )
  AND (
    k.id = mk.keyword_id
  )
  AND (
    cct1.kind = 'complete+verified'
  )
  AND (
    kt.kind = 'movie'
  )