SELECT
  MIN(cn.name) AS movie_company,
  MIN(mi_idx.info) AS rating,
  MIN(t.title) AS complete_euro_dark_movie
FROM complete_cast AS cc, comp_cast_type AS cct1, comp_cast_type AS cct2, company_name AS cn, company_type AS ct, info_type AS it1, info_type AS it2, kind_type AS kt, movie_companies AS mc, movie_info AS mi, movie_info_idx AS mi_idx, movie_keyword AS mk, title AS t, mv938
WHERE
  (
    t.id = mi.movie_id
  )
  AND (
    mi.movie_id = mk.movie_id
  )
  AND (
    mi_idx.info_type_id = it2.id
  )
  AND (
    it2.info = 'rating'
  )
  AND (
    mi_idx.movie_id = cc.movie_id
  )
  AND (
    cc.subject_id = cct1.id
  )
  AND (
    mi_idx.info < '8.5'
  )
  AND (
    mc.movie_id = mi_idx.movie_id
  )
  AND (
    (
      NOT mc.note LIKE '%(USA)%'
    ) AND (
      mc.note LIKE '%(200%)%'
    )
  )
  AND (
    cn.id = mc.company_id
  )
  AND (
    cn.country_code <> '[us]'
  )
  AND (
    ct.id = mc.company_type_id
  )
  AND (
    mk.movie_id = mi_idx.movie_id
  )
  AND (
    mv938.keyword_id = mk.keyword_id
  )
  AND (
    t.id = mk.movie_id
  )
  AND (
    t.production_year > 2000
  )
  AND (
    kt.id = t.kind_id
  )
  AND (
    kt.kind IN ('movie', 'episode')
  )
  AND (
    mi.info IN ('Sweden', 'Norway', 'Germany', 'Denmark', 'Swedish', 'Danish', 'Norwegian', 'German', 'USA', 'American')
  )
  AND (
    it1.id = mi.info_type_id
  )
  AND (
    it1.info = 'countries'
  )
  AND (
    cct2.id = cc.status_id
  )
  AND (
    cct2.kind <> 'complete+verified'
  )
  AND (
    cct1.kind = 'crew'
  )