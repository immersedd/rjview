SELECT
  MIN(cn.name) AS movie_company,
  MIN(mv603.movie_info_idx_info) AS rating,
  MIN(t.title) AS mainstream_movie
FROM company_name AS cn, company_type AS ct, info_type AS it1, info_type AS it2, movie_companies AS mc, movie_info AS mi, title AS t, mv603
WHERE
  (
    t.id = mi.movie_id
  )
  AND (
    mi.movie_id = mc.movie_id
  )
  AND (
    mv603.movie_info_idx_movie_id = t.id
  )
  AND (
    t.id = mc.movie_id
  )
  AND (
    mv603.movie_info_idx_info_type_id = it2.id
  )
  AND (
    it2.info = 'rating'
  )
  AND (
    mc.movie_id = mv603.movie_info_idx_movie_id
  )
  AND (
    mc.company_type_id = ct.id
  )
  AND (
    cn.id = mc.company_id
  )
  AND (
    cn.country_code = '[us]'
  )
  AND (
    (
      t.production_year >= 2000
    ) AND (
      t.production_year <= 2010
    )
  )
  AND (
    mi.info IN ('Drama', 'Horror', 'Western', 'Family')
  )
  AND (
    it1.id = mi.info_type_id
  )
  AND (
    it1.info = 'genres'
  )
  AND (
    ct.kind = 'production companies'
  )