SELECT
  MIN(an.name) AS alternative_name,
  MIN(chn.name) AS voiced_character,
  MIN(n.name) AS voicing_actress,
  MIN(t.title) AS american_movie
FROM aka_name AS an, char_name AS chn, company_name AS cn, movie_companies AS mc, name AS n, role_type AS rt, title AS t, mv1368
WHERE
  (
    n.id = mv1368.cast_info_person_id
  )
  AND (
    mv1368.cast_info_person_id = an.person_id
  )
  AND (
    an.person_id = n.id
  )
  AND (
    mv1368.cast_info_role_id = rt.id
  )
  AND (
    mc.movie_id = mv1368.cast_info_movie_id
  )
  AND (
    (
      mc.note LIKE '%(200%)%'
    )
    AND (
      (
        mc.note LIKE '%(USA)%'
      ) OR (
        mc.note LIKE '%(worldwide)%'
      )
    )
  )
  AND (
    cn.id = mc.company_id
  )
  AND (
    cn.country_code = '[us]'
  )
  AND (
    chn.id = mv1368.cast_info_person_role_id
  )
  AND (
    t.id = mv1368.cast_info_movie_id
  )
  AND (
    (
      t.production_year >= 2007
    ) AND (
      t.production_year <= 2010
    )
  )
  AND (
    (
      n.name LIKE '%Angel%'
    ) AND (
      n.gender = 'f'
    )
  )
  AND (
    rt.role = 'actress'
  )