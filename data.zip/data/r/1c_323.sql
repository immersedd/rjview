SELECT
  MIN(mc.note) AS production_note,
  MIN(t.title) AS movie_title,
  MIN(t.production_year) AS movie_year
FROM info_type AS it, movie_companies AS mc, movie_info_idx AS mi_idx, title AS t, mv323
WHERE
  (
    mc.movie_id = t.id
  )
  AND (
    t.id = mi_idx.movie_id
  )
  AND (
    mi_idx.info_type_id = it.id
  )
  AND (
    it.info = 'top 250 rank'
  )
  AND (
    mc.movie_id = mi_idx.movie_id
  )
  AND (
    (
      NOT mc.note LIKE '%(as Metro-Goldwyn-Mayer Pictures)%'
    )
    AND (
      mc.note LIKE '%(co-production)%'
    )
  )
  AND (
    mv323.company_type_id = mc.company_type_id
  )
  AND (
    t.production_year > 2010
  )