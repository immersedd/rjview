SELECT
  MIN(mc.note) AS production_note,
  MIN(mv448.title_title) AS movie_title,
  MIN(mv448.title_production_year) AS movie_year
FROM company_type AS ct, info_type AS it, movie_companies AS mc, movie_info_idx AS mi_idx, mv448
WHERE
  (
    mc.movie_id = mv448.title_id
  )
  AND (
    mv448.title_id = mi_idx.movie_id
  )
  AND (
    mi_idx.info_type_id = it.id
  )
  AND (
    it.info = 'top 250 rank'
  )
  AND (
    mc.movie_id = mi_idx.movie_id
  )
  AND (
    (
      NOT mc.note LIKE '%(as Metro-Goldwyn-Mayer Pictures)%'
    )
    AND (
      mc.note LIKE '%(co-production)%'
    )
  )
  AND (
    ct.id = mc.company_type_id
  )
  AND (
    ct.kind = 'production companies'
  )