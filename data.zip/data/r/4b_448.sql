SELECT
  MIN(mi_idx.info) AS rating,
  MIN(mv448.title_title) AS movie_title
FROM info_type AS it, keyword AS k, movie_info_idx AS mi_idx, movie_keyword AS mk, mv448
WHERE
  (
    mi_idx.info_type_id = it.id
  )
  AND (
    it.info = 'rating'
  )
  AND (
    mi_idx.info > '9.0'
  )
  AND (
    mv448.title_id = mi_idx.movie_id
  )
  AND (
    mk.movie_id = mv448.title_id
  )
  AND (
    k.id = mk.keyword_id
  )
  AND (
    k.keyword LIKE '%sequel%'
  )