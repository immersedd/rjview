SELECT
  MIN(n.name) AS voicing_actress,
  MIN(t.title) AS kung_fu_panda
FROM aka_name AS an, char_name AS chn, cast_info AS ci, company_name AS cn, movie_companies AS mc, movie_info AS mi, name AS n, role_type AS rt, title AS t, mv257
WHERE
  (
    ci.person_id = n.id
  )
  AND (
    n.id = an.person_id
  )
  AND (
    t.id = mi.movie_id
  )
  AND (
    mi.movie_id = ci.movie_id
  )
  AND (
    t.id = ci.movie_id
  )
  AND (
    ci.movie_id = mc.movie_id
  )
  AND (
    mc.movie_id = t.id
  )
  AND (
    (
      t.production_year >= 2007
    )
    AND (
      t.production_year <= 2008
    )
    AND (
      t.title LIKE '%Kung%Fu%Panda%'
    )
  )
  AND (
    (
      mc.note LIKE '%(200%)%'
    )
    AND (
      (
        mc.note LIKE '%(USA)%'
      ) OR (
        mc.note LIKE '%(worldwide)%'
      )
    )
  )
  AND (
    ci.note = '(voice)'
  )
  AND (
    an.person_id = ci.person_id
  )
  AND (
    chn.id = ci.person_role_id
  )
  AND (
    cn.id = mc.company_id
  )
  AND (
    cn.country_code = '[us]'
  )
  AND (
    (
      NOT mi.info IS NULL
    )
    AND (
      (
        mi.info LIKE 'Japan:%2007%'
      ) OR (
        mi.info LIKE 'USA:%2008%'
      )
    )
  )
  AND (
    mi.info_type_id = mv257.info_type_id
  )
  AND (
    (
      n.name LIKE '%Angel%'
    ) AND (
      n.gender = 'f'
    )
  )
  AND (
    ci.role_id = rt.id
  )
  AND (
    rt.role = 'actress'
  )