SELECT
  MIN(mv841.keyword_keyword) AS movie_keyword,
  MIN(n.name) AS actor_name,
  MIN(t.title) AS hero_movie
FROM cast_info AS ci, name AS n, title AS t, mv841
WHERE
  (
    t.id = ci.movie_id
  )
  AND (
    ci.movie_id = mv841.movie_keyword_movie_id
  )
  AND (
    t.id = mv841.movie_keyword_movie_id
  )
  AND (
    t.production_year > 2000
  )
  AND (
    n.id = ci.person_id
  )