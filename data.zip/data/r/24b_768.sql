SELECT
  MIN(chn.name) AS voiced_char_name,
  MIN(mv768.name_name) AS voicing_actress_name,
  MIN(t.title) AS kung_fu_panda
FROM aka_name AS an, char_name AS chn, cast_info AS ci, company_name AS cn, info_type AS it, keyword AS k, movie_companies AS mc, movie_info AS mi, movie_keyword AS mk, role_type AS rt, title AS t, mv768
WHERE
  (
    t.id = mi.movie_id
  )
  AND (
    mi.movie_id = mk.movie_id
  )
  AND (
    mv768.name_id = an.person_id
  )
  AND (
    an.person_id = ci.person_id
  )
  AND (
    t.id = ci.movie_id
  )
  AND (
    ci.movie_id = mk.movie_id
  )
  AND (
    t.id = mk.movie_id
  )
  AND (
    mk.movie_id = mc.movie_id
  )
  AND (
    it.id = mi.info_type_id
  )
  AND (
    it.info = 'release dates'
  )
  AND (
    mc.company_id = cn.id
  )
  AND (
    (
      cn.country_code = '[us]'
    ) AND (
      cn.name = 'DreamWorks Animation'
    )
  )
  AND (
    t.id = mc.movie_id
  )
  AND (
    (
      t.production_year > 2010
    ) AND (
      t.title LIKE 'Kung Fu Panda%'
    )
  )
  AND (
    k.id = mk.keyword_id
  )
  AND (
    ci.note IN ('(voice)', '(voice: Japanese version)', '(voice) (uncredited)', '(voice: English version)')
  )
  AND (
    mv768.name_id = ci.person_id
  )
  AND (
    chn.id = ci.person_role_id
  )
  AND (
    ci.role_id = rt.id
  )
  AND (
    rt.role = 'actress'
  )
  AND (
    (
      NOT mi.info IS NULL
    )
    AND (
      (
        mi.info LIKE 'Japan:%201%'
      ) OR (
        mi.info LIKE 'USA:%201%'
      )
    )
  )
  AND (
    k.keyword IN ('hero', 'martial-arts', 'hand-to-hand-combat', 'computer-animated-movie')
  )