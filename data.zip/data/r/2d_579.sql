SELECT
  MIN(mv579.title_title) AS movie_title
FROM company_name AS cn, movie_companies AS mc, mv579
WHERE
  (
    mv579.title_id = mc.movie_id
  )
  AND (
    mc.movie_id = mv579.movie_keyword_movie_id
  )
  AND (
    cn.id = mc.company_id
  )
  AND (
    cn.country_code = '[us]'
  )