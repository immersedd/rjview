SELECT
  MIN(t.title) AS american_vhs_movie
FROM info_type AS it, movie_companies AS mc, movie_info AS mi, title AS t, mv323
WHERE
  (
    mv323.company_type_id = mc.company_type_id
  )
  AND (
    (
      mc.note LIKE '%(VHS)%'
    )
    AND (
      mc.note LIKE '%(USA)%'
    )
    AND (
      mc.note LIKE '%(1994)%'
    )
  )
  AND (
    t.id = mc.movie_id
  )
  AND (
    t.production_year > 2010
  )
  AND (
    mi.movie_id = t.id
  )
  AND (
    mi.info IN ('USA', 'America')
  )
  AND (
    mi.info_type_id = it.id
  )