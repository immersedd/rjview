SELECT
  MIN(cn.name) AS producing_company,
  MIN(miidx.info) AS rating,
  MIN(t.title) AS movie_about_winning
FROM company_name AS cn, company_type AS ct, info_type AS it, kind_type AS kt, movie_companies AS mc, movie_info AS mi, movie_info_idx AS miidx, title AS t, mv257
WHERE
  (
    t.id = mi.movie_id
  )
  AND (
    mi.movie_id = mc.movie_id
  )
  AND (
    t.id = mc.movie_id
  )
  AND (
    mc.movie_id = miidx.movie_id
  )
  AND (
    miidx.info_type_id = it.id
  )
  AND (
    it.info = 'rating'
  )
  AND (
    t.id = miidx.movie_id
  )
  AND (
    (
      t.title <> ''
    )
    AND (
      (
        t.title LIKE '%Champion%'
      ) OR (
        t.title LIKE '%Loser%'
      )
    )
  )
  AND (
    kt.id = t.kind_id
  )
  AND (
    kt.kind = 'movie'
  )
  AND (
    cn.id = mc.company_id
  )
  AND (
    cn.country_code = '[us]'
  )
  AND (
    ct.id = mc.company_type_id
  )
  AND (
    ct.kind = 'production companies'
  )
  AND (
    mv257.info_type_id = mi.info_type_id
  )