SELECT
  MIN(mc.note) AS production_note,
  MIN(t.title) AS movie_title,
  MIN(t.production_year) AS movie_year
FROM info_type AS it, movie_companies AS mc, movie_info_idx AS mi_idx, title AS t, mv323
WHERE
  (
    mi_idx.info_type_id = it.id
  )
  AND (
    it.info = 'bottom 10 rank'
  )
  AND (
    mc.movie_id = mi_idx.movie_id
  )
  AND (
    NOT mc.note LIKE '%(as Metro-Goldwyn-Mayer Pictures)%'
  )
  AND (
    mc.company_type_id = mv323.company_type_id
  )
  AND (
    t.id = mc.movie_id
  )
  AND (
    (
      t.production_year >= 2005
    ) AND (
      t.production_year <= 2010
    )
  )