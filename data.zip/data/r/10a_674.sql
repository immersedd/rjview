SELECT
  MIN(chn.name) AS uncredited_voiced_character,
  MIN(mv674.title_title) AS russian_movie
FROM char_name AS chn, cast_info AS ci, company_name AS cn, company_type AS ct, movie_companies AS mc, role_type AS rt, mv674
WHERE
  (
    mv674.title_id = ci.movie_id
  )
  AND (
    ci.movie_id = mc.movie_id
  )
  AND (
    mv674.title_id = mc.movie_id
  )
  AND (
    mc.company_id = cn.id
  )
  AND (
    (
      ci.note LIKE '%(voice)%'
    ) AND (
      ci.note LIKE '%(uncredited)%'
    )
  )
  AND (
    rt.id = ci.role_id
  )
  AND (
    chn.id = ci.person_role_id
  )
  AND (
    ct.id = mc.company_type_id
  )
  AND (
    cn.country_code = '[ru]'
  )
  AND (
    rt.role = 'actor'
  )