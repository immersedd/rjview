SELECT
  MIN(mi.info) AS movie_budget,
  MIN(mi_idx.info) AS movie_votes,
  MIN(t.title) AS movie_title
FROM info_type AS it1, info_type AS it2, movie_info AS mi, movie_info_idx AS mi_idx, name AS n, title AS t, mv129
WHERE
  (
    mi.movie_id = t.id
  )
  AND (
    t.id = mi_idx.movie_id
  )
  AND (
    mi_idx.info_type_id = it2.id
  )
  AND (
    it2.info = 'votes'
  )
  AND (
    mi.movie_id = mi_idx.movie_id
  )
  AND (
    mi.info IN ('Horror', 'Action', 'Sci-Fi', 'Thriller', 'Crime', 'War')
  )
  AND (
    mi.info_type_id = it1.id
  )
  AND (
    mv129.cast_info_movie_id = t.id
  )
  AND (
    n.id = mv129.cast_info_person_id
  )
  AND (
    n.gender = 'm'
  )
  AND (
    it1.info = 'genres'
  )