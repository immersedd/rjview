SELECT
  MIN(mv674.title_title) AS typical_european_movie
FROM company_type AS ct, info_type AS it, movie_companies AS mc, movie_info AS mi, mv674
WHERE
  (
    ct.id = mc.company_type_id
  )
  AND (
    (
      mc.note LIKE '%(theatrical)%'
    ) AND (
      mc.note LIKE '%(France)%'
    )
  )
  AND (
    mv674.title_id = mc.movie_id
  )
  AND (
    mi.movie_id = mv674.title_id
  )
  AND (
    mi.info IN ('Sweden', 'Norway', 'Germany', 'Denmark', 'Swedish', 'Denish', 'Norwegian', 'German')
  )
  AND (
    ct.kind = 'production companies'
  )
  AND (
    mi.info_type_id = it.id
  )