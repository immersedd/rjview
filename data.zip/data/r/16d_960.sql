SELECT
  MIN(an.name) AS cool_actor_pseudonym,
  MIN(t.title) AS series_named_after_char
FROM aka_name AS an, cast_info AS ci, keyword AS k, movie_companies AS mc, movie_keyword AS mk, name AS n, title AS t, mv960
WHERE
  (
    n.id = an.person_id
  )
  AND (
    an.person_id = ci.person_id
  )
  AND (
    t.id = ci.movie_id
  )
  AND (
    ci.movie_id = mk.movie_id
  )
  AND (
    t.id = mc.movie_id
  )
  AND (
    mc.movie_id = mk.movie_id
  )
  AND (
    mk.keyword_id = k.id
  )
  AND (
    k.keyword = 'character-name-in-title'
  )
  AND (
    t.id = mk.movie_id
  )
  AND (
    (
      t.episode_nr >= 5
    ) AND (
      t.episode_nr < 100
    )
  )
  AND (
    mv960.company_name_id = mc.company_id
  )
  AND (
    n.id = ci.person_id
  )