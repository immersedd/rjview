SELECT
  MIN(chn.name) AS character,
  MIN(t.title) AS movie_with_american_producer
FROM char_name AS chn, cast_info AS ci, company_type AS ct, movie_companies AS mc, role_type AS rt, title AS t, mv960
WHERE
  (
    ci.role_id = rt.id
  )
  AND (
    ci.note LIKE '%(producer)%'
  )
  AND (
    ci.movie_id = t.id
  )
  AND (
    chn.id = ci.person_role_id
  )
  AND (
    t.id = mc.movie_id
  )
  AND (
    mc.company_type_id = ct.id
  )
  AND (
    t.production_year > 1990
  )
  AND (
    mc.company_id = mv960.company_name_id
  )