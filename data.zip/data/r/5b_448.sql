SELECT
  MIN(mv448.title_title) AS american_vhs_movie
FROM company_type AS ct, info_type AS it, movie_companies AS mc, movie_info AS mi, mv448
WHERE
  (
    ct.id = mc.company_type_id
  )
  AND (
    (
      mc.note LIKE '%(VHS)%'
    )
    AND (
      mc.note LIKE '%(USA)%'
    )
    AND (
      mc.note LIKE '%(1994)%'
    )
  )
  AND (
    mv448.title_id = mc.movie_id
  )
  AND (
    mi.movie_id = mv448.title_id
  )
  AND (
    mi.info IN ('USA', 'America')
  )
  AND (
    mi.info_type_id = it.id
  )
  AND (
    ct.kind = 'production companies'
  )