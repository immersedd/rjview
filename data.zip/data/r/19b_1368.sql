SELECT
  MIN(n.name) AS voicing_actress,
  MIN(t.title) AS kung_fu_panda
FROM aka_name AS an, char_name AS chn, company_name AS cn, info_type AS it, movie_companies AS mc, movie_info AS mi, name AS n, role_type AS rt, title AS t, mv1368
WHERE
  (
    mv1368.cast_info_person_id = n.id
  )
  AND (
    n.id = an.person_id
  )
  AND (
    t.id = mi.movie_id
  )
  AND (
    mi.movie_id = mv1368.cast_info_movie_id
  )
  AND (
    t.id = mv1368.cast_info_movie_id
  )
  AND (
    mv1368.cast_info_movie_id = mc.movie_id
  )
  AND (
    mc.movie_id = t.id
  )
  AND (
    (
      t.production_year >= 2007
    )
    AND (
      t.production_year <= 2008
    )
    AND (
      t.title LIKE '%Kung%Fu%Panda%'
    )
  )
  AND (
    (
      mc.note LIKE '%(200%)%'
    )
    AND (
      (
        mc.note LIKE '%(USA)%'
      ) OR (
        mc.note LIKE '%(worldwide)%'
      )
    )
  )
  AND (
    an.person_id = mv1368.cast_info_person_id
  )
  AND (
    chn.id = mv1368.cast_info_person_role_id
  )
  AND (
    cn.id = mc.company_id
  )
  AND (
    cn.country_code = '[us]'
  )
  AND (
    (
      NOT mi.info IS NULL
    )
    AND (
      (
        mi.info LIKE 'Japan:%2007%'
      ) OR (
        mi.info LIKE 'USA:%2008%'
      )
    )
  )
  AND (
    mi.info_type_id = it.id
  )
  AND (
    it.info = 'release dates'
  )
  AND (
    (
      n.name LIKE '%Angel%'
    ) AND (
      n.gender = 'f'
    )
  )
  AND (
    mv1368.cast_info_role_id = rt.id
  )
  AND (
    rt.role = 'actress'
  )