SELECT
  MIN(mi.info) AS release_date,
  MIN(t.title) AS internet_movie
FROM aka_title AS at, company_type AS ct, info_type AS it1, keyword AS k, movie_companies AS mc, movie_info AS mi, movie_keyword AS mk, title AS t, mv960
WHERE
  (
    mc.company_id = mv960.company_name_id
  )
  AND (
    (
      mc.note LIKE '%(200%)%'
    ) AND (
      mc.note LIKE '%(worldwide)%'
    )
  )
  AND (
    at.movie_id = mc.movie_id
  )
  AND (
    t.id = at.movie_id
  )
  AND (
    t.production_year > 2000
  )
  AND (
    mi.movie_id = t.id
  )
  AND (
    (
      mi.note LIKE '%internet%'
    ) AND (
      mi.info LIKE 'USA:% 200%'
    )
  )
  AND (
    it1.id = mi.info_type_id
  )
  AND (
    ct.id = mc.company_type_id
  )
  AND (
    mk.movie_id = t.id
  )
  AND (
    k.id = mk.keyword_id
  )
  AND (
    it1.info = 'release dates'
  )