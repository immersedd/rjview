SELECT
  MIN(mc.note) AS production_note,
  MIN(t.title) AS movie_title,
  MIN(t.production_year) AS movie_year
FROM company_type AS ct, movie_companies AS mc, title AS t, mv530
WHERE
  (
    mc.movie_id = mv530.movie_info_idx_movie_id
  )
  AND (
    NOT mc.note LIKE '%(as Metro-Goldwyn-Mayer Pictures)%'
  )
  AND (
    mc.company_type_id = ct.id
  )
  AND (
    t.id = mc.movie_id
  )
  AND (
    t.production_year > 2000
  )
  AND (
    ct.kind = 'production companies'
  )