SELECT
  MIN(mv674.title_title) AS movie_title
FROM keyword AS k, movie_info AS mi, movie_keyword AS mk, mv674
WHERE
  (
    mv674.title_id = mi.movie_id
  )
  AND (
    mi.movie_id = mk.movie_id
  )
  AND (
    mk.keyword_id = k.id
  )
  AND (
    k.keyword LIKE '%sequel%'
  )
  AND (
    mv674.title_id = mk.movie_id
  )
  AND (
    mi.info IN ('Sweden', 'Norway', 'Germany', 'Denmark', 'Swedish', 'Denish', 'Norwegian', 'German')
  )