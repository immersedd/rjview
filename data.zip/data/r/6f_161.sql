SELECT
  MIN(mv161.keyword_keyword) AS movie_keyword,
  MIN(n.name) AS actor_name,
  MIN(mv161.title_title) AS hero_movie
FROM name AS n, mv161
WHERE
  (
    n.id = mv161.cast_info_person_id
  )