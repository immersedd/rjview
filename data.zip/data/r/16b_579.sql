SELECT
  MIN(an.name) AS cool_actor_pseudonym,
  MIN(mv579.title_title) AS series_named_after_char
FROM aka_name AS an, cast_info AS ci, company_name AS cn, movie_companies AS mc, name AS n, mv579
WHERE
  (
    n.id = an.person_id
  )
  AND (
    an.person_id = ci.person_id
  )
  AND (
    mv579.title_id = ci.movie_id
  )
  AND (
    ci.movie_id = mv579.movie_keyword_movie_id
  )
  AND (
    mv579.title_id = mc.movie_id
  )
  AND (
    mc.movie_id = mv579.movie_keyword_movie_id
  )
  AND (
    cn.id = mc.company_id
  )
  AND (
    cn.country_code = '[us]'
  )
  AND (
    n.id = ci.person_id
  )