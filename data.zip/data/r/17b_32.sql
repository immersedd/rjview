SELECT
  MIN(n.name) AS member_in_charnamed_movie,
  MIN(n.name) AS a1
FROM cast_info AS ci, company_name AS cn, movie_companies AS mc, name AS n, title AS t, mv32
WHERE
  (
    ci.movie_id = mv32.movie_keyword_movie_id
  )
  AND (
    n.id = ci.person_id
  )
  AND (
    n.name LIKE 'Z%'
  )
  AND (
    mc.movie_id = ci.movie_id
  )
  AND (
    cn.id = mc.company_id
  )
  AND (
    t.id = ci.movie_id
  )