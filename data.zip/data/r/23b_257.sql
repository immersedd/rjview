SELECT
  MIN(kt.kind) AS movie_kind,
  MIN(t.title) AS complete_nerdy_internet_movie
FROM complete_cast AS cc, comp_cast_type AS cct1, company_name AS cn, company_type AS ct, keyword AS k, kind_type AS kt, movie_companies AS mc, movie_info AS mi, movie_keyword AS mk, title AS t, mv257
WHERE
  (
    t.id = mc.movie_id
  )
  AND (
    mc.movie_id = mk.movie_id
  )
  AND (
    t.id = cc.movie_id
  )
  AND (
    cc.status_id = cct1.id
  )
  AND (
    t.production_year > 2000
  )
  AND (
    kt.id = t.kind_id
  )
  AND (
    mi.movie_id = t.id
  )
  AND (
    (
      mi.note LIKE '%internet%'
    ) AND (
      mi.info LIKE 'USA:% 200%'
    )
  )
  AND (
    mk.movie_id = t.id
  )
  AND (
    cn.id = mc.company_id
  )
  AND (
    cn.country_code = '[us]'
  )
  AND (
    ct.id = mc.company_type_id
  )
  AND (
    mv257.info_type_id = mi.info_type_id
  )
  AND (
    k.id = mk.keyword_id
  )
  AND (
    k.keyword IN ('nerd', 'loner', 'alienation', 'dignity')
  )
  AND (
    cct1.kind = 'complete+verified'
  )
  AND (
    kt.kind = 'movie'
  )