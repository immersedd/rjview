SELECT
  MIN(mi.info) AS release_date,
  MIN(t.title) AS youtube_movie
FROM aka_title AS at, company_name AS cn, company_type AS ct, keyword AS k, movie_companies AS mc, movie_info AS mi, movie_keyword AS mk, title AS t, mv257
WHERE
  (
    mc.company_id = cn.id
  )
  AND (
    (
      cn.country_code = '[us]'
    ) AND (
      cn.name = 'YouTube'
    )
  )
  AND (
    (
      mc.note LIKE '%(200%)%'
    ) AND (
      mc.note LIKE '%(worldwide)%'
    )
  )
  AND (
    at.movie_id = mc.movie_id
  )
  AND (
    mc.company_type_id = ct.id
  )
  AND (
    t.id = at.movie_id
  )
  AND (
    (
      t.production_year >= 2005
    ) AND (
      t.production_year <= 2010
    )
  )
  AND (
    mi.movie_id = t.id
  )
  AND (
    (
      mi.note LIKE '%internet%'
    ) AND (
      mi.info LIKE 'USA:% 200%'
    )
  )
  AND (
    mi.info_type_id = mv257.info_type_id
  )
  AND (
    mk.movie_id = t.id
  )
  AND (
    k.id = mk.keyword_id
  )