SELECT
  MIN(cn.name) AS movie_company,
  MIN(mi_idx.info) AS rating,
  MIN(t.title) AS western_violent_movie
FROM company_name AS cn, company_type AS ct, info_type AS it1, info_type AS it2, kind_type AS kt, movie_companies AS mc, movie_info AS mi, movie_info_idx AS mi_idx, title AS t, mv1093
WHERE
  (
    t.id = mi_idx.movie_id
  )
  AND (
    mi_idx.movie_id = mv1093.movie_keyword_movie_id
  )
  AND (
    t.id = mc.movie_id
  )
  AND (
    mc.movie_id = mv1093.movie_keyword_movie_id
  )
  AND (
    t.id = mi.movie_id
  )
  AND (
    mi.movie_id = mv1093.movie_keyword_movie_id
  )
  AND (
    t.id = mv1093.movie_keyword_movie_id
  )
  AND (
    t.production_year > 2005
  )
  AND (
    t.kind_id = kt.id
  )
  AND (
    mi.info IN ('Sweden', 'Norway', 'Germany', 'Denmark', 'Swedish', 'Danish', 'Norwegian', 'German', 'USA', 'American')
  )
  AND (
    mi.info_type_id = it1.id
  )
  AND (
    it1.info = 'countries'
  )
  AND (
    cn.id = mc.company_id
  )
  AND (
    cn.country_code <> '[us]'
  )
  AND (
    mc.company_type_id = ct.id
  )
  AND (
    mi_idx.info < '8.5'
  )
  AND (
    mi_idx.info_type_id = it2.id
  )
  AND (
    it2.info = 'rating'
  )
  AND (
    kt.kind IN ('movie', 'episode')
  )