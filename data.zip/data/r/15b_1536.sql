SELECT
  MIN(mi.info) AS release_date,
  MIN(mv1536.title_title) AS youtube_movie
FROM aka_title AS at, company_name AS cn, company_type AS ct, info_type AS it1, keyword AS k, movie_companies AS mc, movie_info AS mi, movie_keyword AS mk, mv1536
WHERE
  (
    mc.company_id = cn.id
  )
  AND (
    (
      cn.country_code = '[us]'
    ) AND (
      cn.name = 'YouTube'
    )
  )
  AND (
    (
      mc.note LIKE '%(200%)%'
    ) AND (
      mc.note LIKE '%(worldwide)%'
    )
  )
  AND (
    at.movie_id = mc.movie_id
  )
  AND (
    mc.company_type_id = ct.id
  )
  AND (
    mv1536.title_id = at.movie_id
  )
  AND (
    mi.movie_id = mv1536.title_id
  )
  AND (
    (
      mi.note LIKE '%internet%'
    ) AND (
      mi.info LIKE 'USA:% 200%'
    )
  )
  AND (
    mi.info_type_id = it1.id
  )
  AND (
    it1.info = 'release dates'
  )
  AND (
    mk.movie_id = mv1536.title_id
  )
  AND (
    k.id = mk.keyword_id
  )