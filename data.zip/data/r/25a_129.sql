SELECT
  MIN(mi.info) AS movie_budget,
  MIN(mi_idx.info) AS movie_votes,
  MIN(n.name) AS male_writer,
  MIN(t.title) AS violent_movie_title
FROM info_type AS it1, info_type AS it2, keyword AS k, movie_info AS mi, movie_info_idx AS mi_idx, movie_keyword AS mk, name AS n, title AS t, mv129
WHERE
  (
    mi.movie_id = t.id
  )
  AND (
    t.id = mk.movie_id
  )
  AND (
    mi.movie_id = mv129.cast_info_movie_id
  )
  AND (
    mv129.cast_info_movie_id = mk.movie_id
  )
  AND (
    mi_idx.movie_id = mi.movie_id
  )
  AND (
    mi.movie_id = mk.movie_id
  )
  AND (
    mi_idx.info_type_id = it2.id
  )
  AND (
    it2.info = 'votes'
  )
  AND (
    mk.keyword_id = k.id
  )
  AND (
    k.keyword IN ('murder', 'blood', 'gore', 'death', 'female-nudity')
  )
  AND (
    mi_idx.movie_id = mk.movie_id
  )
  AND (
    mi.info = 'Horror'
  )
  AND (
    mi.info_type_id = it1.id
  )
  AND (
    it1.info = 'genres'
  )
  AND (
    n.id = mv129.cast_info_person_id
  )
  AND (
    n.gender = 'm'
  )