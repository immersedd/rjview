SELECT
  MIN(mi.info) AS movie_budget,
  MIN(mi_idx.info) AS movie_votes,
  MIN(n.name) AS writer,
  MIN(t.title) AS violent_liongate_movie
FROM cast_info AS ci, company_name AS cn, info_type AS it1, info_type AS it2, movie_companies AS mc, movie_info AS mi, movie_info_idx AS mi_idx, name AS n, title AS t, mv1152
WHERE
  (
    mi.movie_id = t.id
  )
  AND (
    t.id = mv1152.movie_keyword_movie_id
  )
  AND (
    mi_idx.movie_id = mi.movie_id
  )
  AND (
    mi.movie_id = mv1152.movie_keyword_movie_id
  )
  AND (
    mi_idx.movie_id = ci.movie_id
  )
  AND (
    ci.movie_id = mv1152.movie_keyword_movie_id
  )
  AND (
    mi_idx.movie_id = mc.movie_id
  )
  AND (
    mc.movie_id = mv1152.movie_keyword_movie_id
  )
  AND (
    mi_idx.info_type_id = it2.id
  )
  AND (
    it2.info = 'votes'
  )
  AND (
    mi_idx.movie_id = mv1152.movie_keyword_movie_id
  )
  AND (
    cn.id = mc.company_id
  )
  AND (
    cn.name LIKE 'Lionsgate%'
  )
  AND (
    ci.note IN ('(writer)', '(head writer)', '(written by)', '(story)', '(story editor)')
  )
  AND (
    mi.info IN ('Horror', 'Thriller')
  )
  AND (
    mi.info_type_id = it1.id
  )
  AND (
    it1.info = 'genres'
  )
  AND (
    n.id = ci.person_id
  )
  AND (
    n.gender = 'm'
  )