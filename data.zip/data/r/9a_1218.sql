SELECT
  MIN(an.name) AS alternative_name,
  MIN(chn.name) AS character_name,
  MIN(t.title) AS movie
FROM aka_name AS an, char_name AS chn, cast_info AS ci, company_name AS cn, name AS n, role_type AS rt, title AS t, mv1218
WHERE
  (
    n.id = ci.person_id
  )
  AND (
    ci.person_id = an.person_id
  )
  AND (
    an.person_id = n.id
  )
  AND (
    ci.note IN ('(voice)', '(voice: Japanese version)', '(voice) (uncredited)', '(voice: English version)')
  )
  AND (
    ci.role_id = rt.id
  )
  AND (
    mv1218.movie_companies_movie_id = ci.movie_id
  )
  AND (
    cn.id = mv1218.movie_companies_company_id
  )
  AND (
    cn.country_code = '[us]'
  )
  AND (
    t.id = ci.movie_id
  )
  AND (
    (
      t.production_year >= 2005
    ) AND (
      t.production_year <= 2015
    )
  )
  AND (
    chn.id = ci.person_role_id
  )
  AND (
    (
      n.name LIKE '%Ang%'
    ) AND (
      n.gender = 'f'
    )
  )
  AND (
    rt.role = 'actress'
  )