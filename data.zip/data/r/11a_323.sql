SELECT
  MIN(cn.name) AS from_company,
  MIN(lt.link) AS movie_link_type,
  MIN(t.title) AS non_polish_sequel_movie
FROM company_name AS cn, keyword AS k, link_type AS lt, movie_companies AS mc, movie_keyword AS mk, movie_link AS ml, title AS t, mv323
WHERE
  (
    ml.movie_id = mk.movie_id
  )
  AND (
    mk.movie_id = mc.movie_id
  )
  AND (
    ml.movie_id = t.id
  )
  AND (
    t.id = mc.movie_id
  )
  AND (
    ml.link_type_id = lt.id
  )
  AND (
    lt.link LIKE '%follow%'
  )
  AND (
    mc.movie_id = ml.movie_id
  )
  AND (
    mc.note IS NULL
  )
  AND (
    mv323.company_type_id = mc.company_type_id
  )
  AND (
    cn.id = mc.company_id
  )
  AND (
    (
      cn.country_code <> '[pl]'
    )
    AND (
      (
        cn.name LIKE '%Film%'
      ) OR (
        cn.name LIKE '%Warner%'
      )
    )
  )
  AND (
    (
      t.production_year >= 1950
    ) AND (
      t.production_year <= 2000
    )
  )
  AND (
    k.id = mk.keyword_id
  )
  AND (
    k.keyword = 'sequel'
  )