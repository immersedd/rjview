SELECT
  MIN(chn.name) AS character_name,
  MIN(mv603.movie_info_idx_info) AS rating,
  MIN(n.name) AS playing_actor,
  MIN(t.title) AS complete_hero_movie
FROM complete_cast AS cc, comp_cast_type AS cct1, comp_cast_type AS cct2, char_name AS chn, cast_info AS ci, info_type AS it2, keyword AS k, kind_type AS kt, movie_keyword AS mk, name AS n, title AS t, mv603
WHERE
  (
    t.id = mv603.movie_info_idx_movie_id
  )
  AND (
    mv603.movie_info_idx_movie_id = ci.movie_id
  )
  AND (
    cct1.id = cc.subject_id
  )
  AND (
    cc.status_id = cct2.id
  )
  AND (
    t.id = cc.movie_id
  )
  AND (
    t.production_year > 2000
  )
  AND (
    ci.movie_id = t.id
  )
  AND (
    n.id = ci.person_id
  )
  AND (
    it2.id = mv603.movie_info_idx_info_type_id
  )
  AND (
    it2.info = 'rating'
  )
  AND (
    chn.id = ci.person_role_id
  )
  AND (
    (
      NOT chn.name IS NULL
    )
    AND (
      (
        chn.name LIKE '%man%'
      ) OR (
        chn.name LIKE '%Man%'
      )
    )
  )
  AND (
    mk.movie_id = t.id
  )
  AND (
    k.id = mk.keyword_id
  )
  AND (
    k.keyword IN ('superhero', 'marvel-comics', 'based-on-comic', 'tv-special', 'fight', 'violence', 'magnet', 'web', 'claw', 'laser')
  )
  AND (
    kt.id = t.kind_id
  )
  AND (
    kt.kind = 'movie'
  )
  AND (
    cct2.kind LIKE '%complete%'
  )
  AND (
    cct1.kind = 'cast'
  )