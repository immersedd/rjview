SELECT
  MIN(n.name) AS member_in_charnamed_movie
FROM cast_info AS ci, company_name AS cn, movie_companies AS mc, name AS n, title AS t, mv32
WHERE
  (
    t.id = ci.movie_id
  )
  AND (
    ci.movie_id = mv32.movie_keyword_movie_id
  )
  AND (
    t.id = mv32.movie_keyword_movie_id
  )
  AND (
    n.id = ci.person_id
  )
  AND (
    n.name LIKE '%B%'
  )
  AND (
    mc.movie_id = ci.movie_id
  )
  AND (
    cn.id = mc.company_id
  )