SELECT
  MIN(t.title) AS movie_title
FROM keyword AS k, movie_companies AS mc, movie_keyword AS mk, title AS t, mv960
WHERE
  (
    t.id = mc.movie_id
  )
  AND (
    mc.movie_id = mk.movie_id
  )
  AND (
    mk.keyword_id = k.id
  )
  AND (
    k.keyword = 'character-name-in-title'
  )
  AND (
    t.id = mk.movie_id
  )
  AND (
    mv960.company_name_id = mc.company_id
  )