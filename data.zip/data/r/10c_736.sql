SELECT
  MIN(chn.name) AS character,
  MIN(t.title) AS movie_with_american_producer
FROM char_name AS chn, company_name AS cn, company_type AS ct, movie_companies AS mc, role_type AS rt, title AS t, mv736
WHERE
  (
    mv736.cast_info_role_id = rt.id
  )
  AND (
    mv736.cast_info_movie_id = t.id
  )
  AND (
    chn.id = mv736.cast_info_person_role_id
  )
  AND (
    t.id = mc.movie_id
  )
  AND (
    mc.company_type_id = ct.id
  )
  AND (
    t.production_year > 1990
  )
  AND (
    mc.company_id = cn.id
  )
  AND (
    cn.country_code = '[us]'
  )