SELECT
  MIN(mv960.company_name_name) AS producing_company,
  MIN(miidx.info) AS rating,
  MIN(t.title) AS movie_about_winning
FROM company_type AS ct, info_type AS it, info_type AS it2, kind_type AS kt, movie_companies AS mc, movie_info AS mi, movie_info_idx AS miidx, title AS t, mv960
WHERE
  (
    t.id = mi.movie_id
  )
  AND (
    mi.movie_id = mc.movie_id
  )
  AND (
    t.id = mc.movie_id
  )
  AND (
    mc.movie_id = miidx.movie_id
  )
  AND (
    miidx.info_type_id = it.id
  )
  AND (
    it.info = 'rating'
  )
  AND (
    t.id = miidx.movie_id
  )
  AND (
    (
      t.title <> ''
    )
    AND (
      (
        t.title LIKE 'Champion%'
      ) OR (
        t.title LIKE 'Loser%'
      )
    )
  )
  AND (
    kt.id = t.kind_id
  )
  AND (
    kt.kind = 'movie'
  )
  AND (
    mv960.company_name_id = mc.company_id
  )
  AND (
    ct.id = mc.company_type_id
  )
  AND (
    ct.kind = 'production companies'
  )
  AND (
    it2.id = mi.info_type_id
  )
  AND (
    it2.info = 'release dates'
  )