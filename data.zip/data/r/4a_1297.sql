SELECT
  MIN(mi_idx.info) AS rating,
  MIN(t.title) AS movie_title
FROM info_type AS it, movie_info_idx AS mi_idx, title AS t, mv1297
WHERE
  (
    mi_idx.movie_id = t.id
  )
  AND (
    t.id = mv1297.movie_keyword_movie_id
  )
  AND (
    mi_idx.info_type_id = it.id
  )
  AND (
    it.info = 'rating'
  )
  AND (
    mi_idx.movie_id = mv1297.movie_keyword_movie_id
  )
  AND (
    mi_idx.info > '5.0'
  )
  AND (
    t.production_year > 2005
  )