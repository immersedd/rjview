SELECT
  MIN(mv507.kind_type_kind) AS movie_kind,
  MIN(mv507.title_title) AS complete_nerdy_internet_movie
FROM company_name AS cn, company_type AS ct, info_type AS it1, keyword AS k, movie_companies AS mc, movie_info AS mi, movie_keyword AS mk, mv507
WHERE
  (
    mv507.title_id = mc.movie_id
  )
  AND (
    mc.movie_id = mk.movie_id
  )
  AND (
    mi.movie_id = mv507.title_id
  )
  AND (
    (
      mi.note LIKE '%internet%'
    ) AND (
      mi.info LIKE 'USA:% 200%'
    )
  )
  AND (
    mk.movie_id = mv507.title_id
  )
  AND (
    cn.id = mc.company_id
  )
  AND (
    cn.country_code = '[us]'
  )
  AND (
    ct.id = mc.company_type_id
  )
  AND (
    it1.id = mi.info_type_id
  )
  AND (
    it1.info = 'release dates'
  )
  AND (
    k.id = mk.keyword_id
  )
  AND (
    k.keyword IN ('nerd', 'loner', 'alienation', 'dignity')
  )