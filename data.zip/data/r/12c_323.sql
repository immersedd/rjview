SELECT
  MIN(cn.name) AS movie_company,
  MIN(mi_idx.info) AS rating,
  MIN(t.title) AS mainstream_movie
FROM company_name AS cn, info_type AS it1, info_type AS it2, movie_companies AS mc, movie_info AS mi, movie_info_idx AS mi_idx, title AS t, mv323
WHERE
  (
    t.id = mi.movie_id
  )
  AND (
    mi.movie_id = mc.movie_id
  )
  AND (
    mi_idx.movie_id = t.id
  )
  AND (
    t.id = mc.movie_id
  )
  AND (
    mi_idx.info_type_id = it2.id
  )
  AND (
    it2.info = 'rating'
  )
  AND (
    mi_idx.info > '7.0'
  )
  AND (
    mc.movie_id = mi_idx.movie_id
  )
  AND (
    mc.company_type_id = mv323.company_type_id
  )
  AND (
    cn.id = mc.company_id
  )
  AND (
    cn.country_code = '[us]'
  )
  AND (
    (
      t.production_year >= 2000
    ) AND (
      t.production_year <= 2010
    )
  )
  AND (
    mi.info IN ('Drama', 'Horror', 'Western', 'Family')
  )
  AND (
    it1.id = mi.info_type_id
  )
  AND (
    it1.info = 'genres'
  )