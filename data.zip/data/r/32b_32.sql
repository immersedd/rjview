SELECT
  MIN(lt.link) AS link_type,
  MIN(t1.title) AS first_movie,
  MIN(t2.title) AS second_movie
FROM link_type AS lt, movie_link AS ml, title AS t1, title AS t2, mv32
WHERE
  (
    ml.movie_id = mv32.movie_keyword_movie_id
  )
  AND (
    lt.id = ml.link_type_id
  )
  AND (
    t1.id = mv32.movie_keyword_movie_id
  )
  AND (
    t2.id = ml.linked_movie_id
  )