SELECT
  MIN(mi.info) AS budget,
  MIN(t.title) AS unsuccsessful_movie
FROM company_name AS cn, company_type AS ct, info_type AS it1, movie_companies AS mc, movie_info AS mi, title AS t, mv530
WHERE
  (
    t.id = mi.movie_id
  )
  AND (
    mi.movie_id = mc.movie_id
  )
  AND (
    t.id = mc.movie_id
  )
  AND (
    mc.movie_id = mv530.movie_info_idx_movie_id
  )
  AND (
    t.id = mv530.movie_info_idx_movie_id
  )
  AND (
    (
      t.production_year > 2000
    )
    AND (
      (
        t.title LIKE 'Birdemic%'
      ) OR (
        t.title LIKE '%Movie%'
      )
    )
  )
  AND (
    ct.id = mc.company_type_id
  )
  AND (
    cn.id = mc.company_id
  )
  AND (
    cn.country_code = '[us]'
  )
  AND (
    it1.id = mi.info_type_id
  )
  AND (
    it1.info = 'budget'
  )
  AND (
    (
      NOT ct.kind IS NULL
    )
    AND (
      (
        ct.kind = 'production companies'
      ) OR (
        ct.kind = 'distributors'
      )
    )
  )