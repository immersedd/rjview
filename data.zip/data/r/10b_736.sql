SELECT
  MIN(chn.name) AS character,
  MIN(t.title) AS russian_mov_with_actor_producer
FROM char_name AS chn, company_name AS cn, company_type AS ct, movie_companies AS mc, role_type AS rt, title AS t, mv736
WHERE
  (
    t.id = mv736.cast_info_movie_id
  )
  AND (
    mv736.cast_info_movie_id = mc.movie_id
  )
  AND (
    t.id = mc.movie_id
  )
  AND (
    mc.company_id = cn.id
  )
  AND (
    t.production_year > 2010
  )
  AND (
    mv736.cast_info_role_id = rt.id
  )
  AND (
    chn.id = mv736.cast_info_person_role_id
  )
  AND (
    ct.id = mc.company_type_id
  )
  AND (
    cn.country_code = '[ru]'
  )
  AND (
    rt.role = 'actor'
  )