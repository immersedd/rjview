SELECT
  MIN(mv768.name_name) AS voicing_actress,
  MIN(t.title) AS jap_engl_voiced_movie
FROM aka_name AS an, char_name AS chn, cast_info AS ci, company_name AS cn, info_type AS it, movie_companies AS mc, movie_info AS mi, role_type AS rt, title AS t, mv768
WHERE
  (
    mv768.name_id = an.person_id
  )
  AND (
    an.person_id = ci.person_id
  )
  AND (
    mi.info_type_id = it.id
  )
  AND (
    it.info = 'release dates'
  )
  AND (
    (
      NOT mi.info IS NULL
    )
    AND (
      (
        mi.info LIKE 'Japan:%200%'
      ) OR (
        mi.info LIKE 'USA:%200%'
      )
    )
  )
  AND (
    t.id = mi.movie_id
  )
  AND (
    t.production_year > 2000
  )
  AND (
    ci.movie_id = t.id
  )
  AND (
    ci.note IN ('(voice)', '(voice: Japanese version)', '(voice) (uncredited)', '(voice: English version)')
  )
  AND (
    ci.role_id = rt.id
  )
  AND (
    mv768.name_id = ci.person_id
  )
  AND (
    chn.id = ci.person_role_id
  )
  AND (
    mc.movie_id = t.id
  )
  AND (
    cn.id = mc.company_id
  )
  AND (
    cn.country_code = '[us]'
  )
  AND (
    rt.role = 'actress'
  )