SELECT
  MIN(mc.note) AS production_note,
  MIN(mv1536.title_title) AS movie_title,
  MIN(mv1536.title_production_year) AS movie_year
FROM company_type AS ct, info_type AS it, movie_companies AS mc, movie_info_idx AS mi_idx, mv1536
WHERE
  (
    mi_idx.info_type_id = it.id
  )
  AND (
    it.info = 'bottom 10 rank'
  )
  AND (
    mc.movie_id = mi_idx.movie_id
  )
  AND (
    NOT mc.note LIKE '%(as Metro-Goldwyn-Mayer Pictures)%'
  )
  AND (
    mc.company_type_id = ct.id
  )
  AND (
    mv1536.title_id = mc.movie_id
  )
  AND (
    ct.kind = 'production companies'
  )