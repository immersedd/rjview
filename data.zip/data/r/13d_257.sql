SELECT
  MIN(cn.name) AS producing_company,
  MIN(miidx.info) AS rating,
  MIN(t.title) AS movie
FROM company_name AS cn, company_type AS ct, info_type AS it, kind_type AS kt, movie_companies AS mc, movie_info AS mi, movie_info_idx AS miidx, title AS t, mv257
WHERE
  (
    miidx.info_type_id = it.id
  )
  AND (
    it.info = 'rating'
  )
  AND (
    t.id = miidx.movie_id
  )
  AND (
    t.kind_id = kt.id
  )
  AND (
    mc.movie_id = t.id
  )
  AND (
    ct.id = mc.company_type_id
  )
  AND (
    cn.id = mc.company_id
  )
  AND (
    cn.country_code = '[us]'
  )
  AND (
    mi.movie_id = t.id
  )
  AND (
    mi.info_type_id = mv257.info_type_id
  )
  AND (
    kt.kind = 'movie'
  )
  AND (
    ct.kind = 'production companies'
  )