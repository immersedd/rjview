SELECT
  MIN(t.title) AS movie_title
FROM movie_info AS mi, title AS t, mv1297
WHERE
  (
    t.id = mi.movie_id
  )
  AND (
    mi.movie_id = mv1297.movie_keyword_movie_id
  )
  AND (
    t.id = mv1297.movie_keyword_movie_id
  )
  AND (
    t.production_year > 2010
  )
  AND (
    mi.info = 'Bulgaria'
  )