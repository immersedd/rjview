SELECT
  MIN(t.title) AS movie_title
FROM company_name AS cn, movie_companies AS mc, title AS t, mv32
WHERE
  (
    mc.movie_id = t.id
  )
  AND (
    t.id = mv32.movie_keyword_movie_id
  )
  AND (
    mc.movie_id = mv32.movie_keyword_movie_id
  )
  AND (
    cn.id = mc.company_id
  )
  AND (
    cn.country_code = '[nl]'
  )