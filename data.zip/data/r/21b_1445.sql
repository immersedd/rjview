SELECT
  MIN(cn.name) AS company_name,
  MIN(mv1445.link_type_link) AS link_type,
  MIN(t.title) AS german_follow_up
FROM company_name AS cn, company_type AS ct, keyword AS k, movie_companies AS mc, movie_info AS mi, movie_keyword AS mk, title AS t, mv1445
WHERE
  (
    mv1445.movie_link_movie_id = t.id
  )
  AND (
    t.id = mk.movie_id
  )
  AND (
    mv1445.movie_link_movie_id = mk.movie_id
  )
  AND (
    mk.movie_id = mc.movie_id
  )
  AND (
    mv1445.movie_link_movie_id = mi.movie_id
  )
  AND (
    mi.movie_id = mc.movie_id
  )
  AND (
    mc.movie_id = mv1445.movie_link_movie_id
  )
  AND (
    mc.note IS NULL
  )
  AND (
    ct.id = mc.company_type_id
  )
  AND (
    cn.id = mc.company_id
  )
  AND (
    (
      cn.country_code <> '[pl]'
    )
    AND (
      (
        cn.name LIKE '%Film%'
      ) OR (
        cn.name LIKE '%Warner%'
      )
    )
  )
  AND (
    mi.info IN ('Germany', 'German')
  )
  AND (
    k.id = mk.keyword_id
  )
  AND (
    k.keyword = 'sequel'
  )
  AND (
    (
      t.production_year >= 2000
    ) AND (
      t.production_year <= 2010
    )
  )
  AND (
    ct.kind = 'production companies'
  )