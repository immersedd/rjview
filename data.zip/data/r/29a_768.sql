SELECT
  MIN(chn.name) AS voiced_char,
  MIN(mv768.name_name) AS voicing_actress,
  MIN(t.title) AS voiced_animation
FROM aka_name AS an, complete_cast AS cc, comp_cast_type AS cct1, comp_cast_type AS cct2, char_name AS chn, cast_info AS ci, company_name AS cn, info_type AS it, info_type AS it3, keyword AS k, movie_companies AS mc, movie_info AS mi, movie_keyword AS mk, person_info AS pi, role_type AS rt, title AS t, mv768
WHERE
  (
    t.id = mk.movie_id
  )
  AND (
    mk.movie_id = mc.movie_id
  )
  AND (
    mv768.name_id = pi.person_id
  )
  AND (
    pi.person_id = an.person_id
  )
  AND (
    t.id = mi.movie_id
  )
  AND (
    mi.movie_id = mc.movie_id
  )
  AND (
    cct1.id = cc.subject_id
  )
  AND (
    cc.status_id = cct2.id
  )
  AND (
    ci.movie_id = cc.movie_id
  )
  AND (
    ci.note IN ('(voice)', '(voice) (uncredited)', '(voice: English version)')
  )
  AND (
    an.person_id = ci.person_id
  )
  AND (
    mc.movie_id = ci.movie_id
  )
  AND (
    t.id = mc.movie_id
  )
  AND (
    (
      t.production_year >= 2000
    )
    AND (
      t.production_year <= 2010
    )
    AND (
      t.title = 'Shrek 2'
    )
  )
  AND (
    mv768.name_id = ci.person_id
  )
  AND (
    rt.id = ci.role_id
  )
  AND (
    rt.role = 'actress'
  )
  AND (
    cn.id = mc.company_id
  )
  AND (
    cn.country_code = '[us]'
  )
  AND (
    (
      NOT mi.info IS NULL
    )
    AND (
      (
        mi.info LIKE 'Japan:%200%'
      ) OR (
        mi.info LIKE 'USA:%200%'
      )
    )
  )
  AND (
    it.id = mi.info_type_id
  )
  AND (
    it.info = 'release dates'
  )
  AND (
    chn.id = ci.person_role_id
  )
  AND (
    chn.name = 'Queen'
  )
  AND (
    it3.id = pi.info_type_id
  )
  AND (
    it3.info = 'trivia'
  )
  AND (
    k.id = mk.keyword_id
  )
  AND (
    cct2.kind = 'complete+verified'
  )
  AND (
    cct1.kind = 'cast'
  )
  AND (
    k.keyword = 'computer-animation'
  )