SELECT
  MIN(mi.info) AS movie_budget,
  MIN(mv1200.movie_info_idx_info) AS movie_votes,
  MIN(t.title) AS movie_title
FROM cast_info AS ci, info_type AS it1, movie_info AS mi, name AS n, title AS t, mv1200
WHERE
  (
    mi.movie_id = t.id
  )
  AND (
    t.id = mv1200.movie_info_idx_movie_id
  )
  AND (
    mi.movie_id = mv1200.movie_info_idx_movie_id
  )
  AND (
    mi.info IN ('Horror', 'Action', 'Sci-Fi', 'Thriller', 'Crime', 'War')
  )
  AND (
    mi.info_type_id = it1.id
  )
  AND (
    ci.movie_id = t.id
  )
  AND (
    ci.note IN ('(writer)', '(head writer)', '(written by)', '(story)', '(story editor)')
  )
  AND (
    n.id = ci.person_id
  )
  AND (
    n.gender = 'm'
  )
  AND (
    it1.info = 'genres'
  )