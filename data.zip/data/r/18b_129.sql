SELECT
  MIN(mi.info) AS movie_budget,
  MIN(mi_idx.info) AS movie_votes,
  MIN(t.title) AS movie_title
FROM info_type AS it1, info_type AS it2, movie_info AS mi, movie_info_idx AS mi_idx, name AS n, title AS t, mv129
WHERE
  (
    mi_idx.info_type_id = it2.id
  )
  AND (
    it2.info = 'rating'
  )
  AND (
    mi_idx.info > '8.0'
  )
  AND (
    t.id = mi_idx.movie_id
  )
  AND (
    (
      t.production_year >= 2008
    ) AND (
      t.production_year <= 2014
    )
  )
  AND (
    mi.movie_id = t.id
  )
  AND (
    (
      mi.note IS NULL
    ) AND (
      mi.info IN ('Horror', 'Thriller')
    )
  )
  AND (
    mi.info_type_id = it1.id
  )
  AND (
    mv129.cast_info_movie_id = t.id
  )
  AND (
    n.id = mv129.cast_info_person_id
  )
  AND (
    (
      NOT n.gender IS NULL
    ) AND (
      n.gender = 'f'
    )
  )
  AND (
    it1.info = 'genres'
  )