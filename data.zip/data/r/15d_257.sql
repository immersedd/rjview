SELECT
  MIN(at.title) AS aka_title,
  MIN(t.title) AS internet_movie_title
FROM aka_title AS at, company_name AS cn, company_type AS ct, keyword AS k, movie_companies AS mc, movie_info AS mi, movie_keyword AS mk, title AS t, mv257
WHERE
  (
    t.id = at.movie_id
  )
  AND (
    at.movie_id = mk.movie_id
  )
  AND (
    mi.info_type_id = mv257.info_type_id
  )
  AND (
    mi.note LIKE '%internet%'
  )
  AND (
    t.id = mi.movie_id
  )
  AND (
    t.production_year > 1990
  )
  AND (
    mc.movie_id = t.id
  )
  AND (
    cn.id = mc.company_id
  )
  AND (
    cn.country_code = '[us]'
  )
  AND (
    ct.id = mc.company_type_id
  )
  AND (
    mk.movie_id = t.id
  )
  AND (
    k.id = mk.keyword_id
  )