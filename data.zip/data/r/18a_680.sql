SELECT
  MIN(mi.info) AS movie_budget,
  MIN(mi_idx.info) AS movie_votes,
  MIN(t.title) AS movie_title
FROM cast_info AS ci, info_type AS it2, movie_info AS mi, movie_info_idx AS mi_idx, name AS n, title AS t, mv680
WHERE
  (
    mi_idx.info_type_id = it2.id
  )
  AND (
    it2.info = 'votes'
  )
  AND (
    mi.movie_id = mi_idx.movie_id
  )
  AND (
    mi.info_type_id = mv680.info_type_id
  )
  AND (
    ci.movie_id = mi.movie_id
  )
  AND (
    ci.note IN ('(producer)', '(executive producer)')
  )
  AND (
    n.id = ci.person_id
  )
  AND (
    (
      n.name LIKE '%Tim%'
    ) AND (
      n.gender = 'm'
    )
  )
  AND (
    t.id = mi.movie_id
  )