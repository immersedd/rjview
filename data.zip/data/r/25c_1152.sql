SELECT
  MIN(mi.info) AS movie_budget,
  MIN(mi_idx.info) AS movie_votes,
  MIN(n.name) AS male_writer,
  MIN(t.title) AS violent_movie_title
FROM cast_info AS ci, info_type AS it1, info_type AS it2, movie_info AS mi, movie_info_idx AS mi_idx, name AS n, title AS t, mv1152
WHERE
  (
    mi.movie_id = t.id
  )
  AND (
    t.id = mv1152.movie_keyword_movie_id
  )
  AND (
    mi.movie_id = ci.movie_id
  )
  AND (
    ci.movie_id = mv1152.movie_keyword_movie_id
  )
  AND (
    mi_idx.movie_id = mi.movie_id
  )
  AND (
    mi.movie_id = mv1152.movie_keyword_movie_id
  )
  AND (
    mi.info_type_id = it1.id
  )
  AND (
    it1.info = 'genres'
  )
  AND (
    mi_idx.info_type_id = it2.id
  )
  AND (
    it2.info = 'votes'
  )
  AND (
    mi_idx.movie_id = mv1152.movie_keyword_movie_id
  )
  AND (
    mi.info IN ('Horror', 'Action', 'Sci-Fi', 'Thriller', 'Crime', 'War')
  )
  AND (
    ci.note IN ('(writer)', '(head writer)', '(written by)', '(story)', '(story editor)')
  )
  AND (
    n.id = ci.person_id
  )
  AND (
    n.gender = 'm'
  )