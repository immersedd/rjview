SELECT
  MIN(mi.info) AS release_date,
  MIN(t.title) AS modern_american_internet_movie
FROM aka_title AS at, company_name AS cn, company_type AS ct, keyword AS k, movie_companies AS mc, movie_info AS mi, movie_keyword AS mk, title AS t, mv257
WHERE
  (
    mi.info_type_id = mv257.info_type_id
  )
  AND (
    (
      NOT mi.info IS NULL
    )
    AND (
      mi.note LIKE '%internet%'
    )
    AND (
      (
        mi.info LIKE 'USA:% 199%'
      ) OR (
        mi.info LIKE 'USA:% 200%'
      )
    )
  )
  AND (
    t.id = mi.movie_id
  )
  AND (
    t.production_year > 1990
  )
  AND (
    mc.movie_id = t.id
  )
  AND (
    cn.id = mc.company_id
  )
  AND (
    cn.country_code = '[us]'
  )
  AND (
    ct.id = mc.company_type_id
  )
  AND (
    mk.movie_id = t.id
  )
  AND (
    k.id = mk.keyword_id
  )
  AND (
    at.movie_id = t.id
  )