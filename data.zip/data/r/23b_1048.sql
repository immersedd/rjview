SELECT
  MIN(kt.kind) AS movie_kind,
  MIN(t.title) AS complete_nerdy_internet_movie
FROM complete_cast AS cc, comp_cast_type AS cct1, company_name AS cn, company_type AS ct, info_type AS it1, keyword AS k, kind_type AS kt, movie_companies AS mc, movie_keyword AS mk, title AS t, mv1048
WHERE
  (
    t.id = mc.movie_id
  )
  AND (
    mc.movie_id = mk.movie_id
  )
  AND (
    t.id = cc.movie_id
  )
  AND (
    cc.status_id = cct1.id
  )
  AND (
    t.production_year > 2000
  )
  AND (
    kt.id = t.kind_id
  )
  AND (
    mv1048.movie_info_movie_id = t.id
  )
  AND (
    mk.movie_id = t.id
  )
  AND (
    cn.id = mc.company_id
  )
  AND (
    cn.country_code = '[us]'
  )
  AND (
    ct.id = mc.company_type_id
  )
  AND (
    it1.id = mv1048.movie_info_info_type_id
  )
  AND (
    it1.info = 'release dates'
  )
  AND (
    k.id = mk.keyword_id
  )
  AND (
    k.keyword IN ('nerd', 'loner', 'alienation', 'dignity')
  )
  AND (
    cct1.kind = 'complete+verified'
  )
  AND (
    kt.kind = 'movie'
  )