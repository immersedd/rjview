SELECT
  MIN(mi_idx.info) AS rating,
  MIN(mv674.title_title) AS movie_title
FROM info_type AS it, keyword AS k, movie_info_idx AS mi_idx, movie_keyword AS mk, mv674
WHERE
  (
    mi_idx.movie_id = mv674.title_id
  )
  AND (
    mv674.title_id = mk.movie_id
  )
  AND (
    mi_idx.info_type_id = it.id
  )
  AND (
    it.info = 'rating'
  )
  AND (
    mk.keyword_id = k.id
  )
  AND (
    k.keyword LIKE '%sequel%'
  )
  AND (
    mi_idx.movie_id = mk.movie_id
  )
  AND (
    mi_idx.info > '5.0'
  )