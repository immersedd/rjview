SELECT
  MIN(t.title) AS american_movie
FROM info_type AS it, movie_companies AS mc, movie_info AS mi, title AS t, mv323
WHERE
  (
    mc.company_type_id = mv323.company_type_id
  )
  AND (
    (
      NOT mc.note LIKE '%(TV)%'
    ) AND (
      mc.note LIKE '%(USA)%'
    )
  )
  AND (
    t.id = mc.movie_id
  )
  AND (
    t.production_year > 1990
  )
  AND (
    mi.movie_id = t.id
  )
  AND (
    mi.info IN ('Sweden', 'Norway', 'Germany', 'Denmark', 'Swedish', 'Denish', 'Norwegian', 'German', 'USA', 'American')
  )
  AND (
    it.id = mi.info_type_id
  )