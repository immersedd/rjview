SELECT
  MIN(an.name) AS alternative_name,
  MIN(chn.name) AS character_name,
  MIN(t.title) AS movie
FROM aka_name AS an, char_name AS chn, cast_info AS ci, movie_companies AS mc, name AS n, role_type AS rt, title AS t, mv960
WHERE
  (
    n.id = ci.person_id
  )
  AND (
    ci.person_id = an.person_id
  )
  AND (
    an.person_id = n.id
  )
  AND (
    ci.note IN ('(voice)', '(voice: Japanese version)', '(voice) (uncredited)', '(voice: English version)')
  )
  AND (
    ci.role_id = rt.id
  )
  AND (
    mc.movie_id = ci.movie_id
  )
  AND (
    (
      NOT mc.note IS NULL
    )
    AND (
      (
        mc.note LIKE '%(USA)%'
      ) OR (
        mc.note LIKE '%(worldwide)%'
      )
    )
  )
  AND (
    mv960.company_name_id = mc.company_id
  )
  AND (
    t.id = ci.movie_id
  )
  AND (
    (
      t.production_year >= 2005
    ) AND (
      t.production_year <= 2015
    )
  )
  AND (
    chn.id = ci.person_role_id
  )
  AND (
    (
      n.name LIKE '%Ang%'
    ) AND (
      n.gender = 'f'
    )
  )
  AND (
    rt.role = 'actress'
  )