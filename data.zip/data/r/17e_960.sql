SELECT
  MIN(n.name) AS member_in_charnamed_movie
FROM cast_info AS ci, keyword AS k, movie_companies AS mc, movie_keyword AS mk, name AS n, title AS t, mv960
WHERE
  (
    t.id = ci.movie_id
  )
  AND (
    ci.movie_id = mk.movie_id
  )
  AND (
    t.id = mc.movie_id
  )
  AND (
    mc.movie_id = mk.movie_id
  )
  AND (
    mk.keyword_id = k.id
  )
  AND (
    k.keyword = 'character-name-in-title'
  )
  AND (
    t.id = mk.movie_id
  )
  AND (
    mv960.company_name_id = mc.company_id
  )
  AND (
    n.id = ci.person_id
  )