SELECT
  MIN(n.name) AS voicing_actress,
  MIN(t.title) AS voiced_movie
FROM aka_name AS an, char_name AS chn, cast_info AS ci, company_name AS cn, info_type AS it, movie_info AS mi, name AS n, role_type AS rt, title AS t, mv1218
WHERE
  (
    mi.info_type_id = it.id
  )
  AND (
    it.info = 'release dates'
  )
  AND (
    (
      NOT mi.info IS NULL
    )
    AND (
      (
        mi.info LIKE 'Japan:%200%'
      ) OR (
        mi.info LIKE 'USA:%200%'
      )
    )
  )
  AND (
    t.id = mi.movie_id
  )
  AND (
    (
      t.production_year >= 2005
    ) AND (
      t.production_year <= 2009
    )
  )
  AND (
    mv1218.movie_companies_movie_id = t.id
  )
  AND (
    cn.id = mv1218.movie_companies_company_id
  )
  AND (
    cn.country_code = '[us]'
  )
  AND (
    ci.movie_id = t.id
  )
  AND (
    ci.note IN ('(voice)', '(voice: Japanese version)', '(voice) (uncredited)', '(voice: English version)')
  )
  AND (
    rt.id = ci.role_id
  )
  AND (
    chn.id = ci.person_role_id
  )
  AND (
    an.person_id = ci.person_id
  )
  AND (
    n.id = ci.person_id
  )
  AND (
    (
      n.name LIKE '%Ang%'
    ) AND (
      n.gender = 'f'
    )
  )
  AND (
    rt.role = 'actress'
  )