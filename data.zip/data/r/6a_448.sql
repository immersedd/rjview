SELECT
  MIN(k.keyword) AS movie_keyword,
  MIN(n.name) AS actor_name,
  MIN(mv448.title_title) AS marvel_movie
FROM cast_info AS ci, keyword AS k, movie_keyword AS mk, name AS n, mv448
WHERE
  (
    mv448.title_id = ci.movie_id
  )
  AND (
    ci.movie_id = mk.movie_id
  )
  AND (
    mk.keyword_id = k.id
  )
  AND (
    k.keyword = 'marvel-cinematic-universe'
  )
  AND (
    mv448.title_id = mk.movie_id
  )
  AND (
    n.id = ci.person_id
  )
  AND (
    n.name LIKE '%Downey%Robert%'
  )