SELECT
  MIN(mv448.title_title) AS movie_title
FROM keyword AS k, movie_info AS mi, movie_keyword AS mk, mv448
WHERE
  (
    mv448.title_id = mi.movie_id
  )
  AND (
    mi.movie_id = mk.movie_id
  )
  AND (
    mk.keyword_id = k.id
  )
  AND (
    k.keyword LIKE '%sequel%'
  )
  AND (
    mv448.title_id = mk.movie_id
  )
  AND (
    mi.info = 'Bulgaria'
  )