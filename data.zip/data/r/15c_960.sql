SELECT
  MIN(mi.info) AS release_date,
  MIN(t.title) AS modern_american_internet_movie
FROM aka_title AS at, company_type AS ct, info_type AS it1, keyword AS k, movie_companies AS mc, movie_info AS mi, movie_keyword AS mk, title AS t, mv960
WHERE
  (
    mi.info_type_id = it1.id
  )
  AND (
    it1.info = 'release dates'
  )
  AND (
    (
      NOT mi.info IS NULL
    )
    AND (
      mi.note LIKE '%internet%'
    )
    AND (
      (
        mi.info LIKE 'USA:% 199%'
      ) OR (
        mi.info LIKE 'USA:% 200%'
      )
    )
  )
  AND (
    t.id = mi.movie_id
  )
  AND (
    t.production_year > 1990
  )
  AND (
    mc.movie_id = t.id
  )
  AND (
    mv960.company_name_id = mc.company_id
  )
  AND (
    ct.id = mc.company_type_id
  )
  AND (
    mk.movie_id = t.id
  )
  AND (
    k.id = mk.keyword_id
  )
  AND (
    at.movie_id = t.id
  )