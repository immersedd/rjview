SELECT
  MIN(an.name) AS alternative_name,
  MIN(chn.name) AS voiced_character_name,
  MIN(n.name) AS voicing_actress,
  MIN(t.title) AS american_movie
FROM aka_name AS an, char_name AS chn, cast_info AS ci, movie_companies AS mc, name AS n, role_type AS rt, title AS t, mv960
WHERE
  (
    ci.movie_id = t.id
  )
  AND (
    t.id = mc.movie_id
  )
  AND (
    n.id = ci.person_id
  )
  AND (
    ci.person_id = an.person_id
  )
  AND (
    an.person_id = n.id
  )
  AND (
    ci.note IN ('(voice)', '(voice: Japanese version)', '(voice) (uncredited)', '(voice: English version)')
  )
  AND (
    ci.role_id = rt.id
  )
  AND (
    chn.id = ci.person_role_id
  )
  AND (
    mc.movie_id = ci.movie_id
  )
  AND (
    mv960.company_name_id = mc.company_id
  )
  AND (
    (
      n.name LIKE '%An%'
    ) AND (
      n.gender = 'f'
    )
  )
  AND (
    rt.role = 'actress'
  )