SELECT
  MIN(cn.name) AS movie_company,
  MIN(mi_idx.info) AS rating,
  MIN(mv674.title_title) AS western_violent_movie
FROM company_name AS cn, company_type AS ct, info_type AS it1, info_type AS it2, keyword AS k, kind_type AS kt, movie_companies AS mc, movie_info AS mi, movie_info_idx AS mi_idx, movie_keyword AS mk, mv674
WHERE
  (
    mv674.title_id = mi_idx.movie_id
  )
  AND (
    mi_idx.movie_id = mk.movie_id
  )
  AND (
    mv674.title_id = mi.movie_id
  )
  AND (
    mi.movie_id = mk.movie_id
  )
  AND (
    mv674.title_id = mc.movie_id
  )
  AND (
    mc.movie_id = mk.movie_id
  )
  AND (
    mk.keyword_id = k.id
  )
  AND (
    k.keyword IN ('murder', 'murder-in-title', 'blood', 'violence')
  )
  AND (
    mv674.title_id = mk.movie_id
  )
  AND (
    mv674.title_kind_id = kt.id
  )
  AND (
    (
      NOT mc.note LIKE '%(USA)%'
    ) AND (
      mc.note LIKE '%(200%)%'
    )
  )
  AND (
    cn.id = mc.company_id
  )
  AND (
    cn.country_code <> '[us]'
  )
  AND (
    mc.company_type_id = ct.id
  )
  AND (
    mi.info IN ('Sweden', 'Norway', 'Germany', 'Denmark', 'Swedish', 'Danish', 'Norwegian', 'German', 'USA', 'American')
  )
  AND (
    mi.info_type_id = it1.id
  )
  AND (
    it1.info = 'countries'
  )
  AND (
    mi_idx.info < '8.5'
  )
  AND (
    mi_idx.info_type_id = it2.id
  )
  AND (
    it2.info = 'rating'
  )
  AND (
    kt.kind IN ('movie', 'episode')
  )