SELECT
  MIN(mv960.company_name_name) AS producing_company,
  MIN(miidx.info) AS rating,
  MIN(t.title) AS movie
FROM company_type AS ct, info_type AS it, info_type AS it2, kind_type AS kt, movie_companies AS mc, movie_info AS mi, movie_info_idx AS miidx, title AS t, mv960
WHERE
  (
    miidx.info_type_id = it.id
  )
  AND (
    it.info = 'rating'
  )
  AND (
    t.id = miidx.movie_id
  )
  AND (
    t.kind_id = kt.id
  )
  AND (
    mc.movie_id = t.id
  )
  AND (
    ct.id = mc.company_type_id
  )
  AND (
    mv960.company_name_id = mc.company_id
  )
  AND (
    mi.movie_id = t.id
  )
  AND (
    mi.info_type_id = it2.id
  )
  AND (
    kt.kind = 'movie'
  )
  AND (
    ct.kind = 'production companies'
  )
  AND (
    it2.info = 'release dates'
  )