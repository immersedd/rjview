SELECT
  MIN(mi_idx.info) AS rating,
  MIN(mv448.title_title) AS northern_dark_movie
FROM info_type AS it1, info_type AS it2, keyword AS k, kind_type AS kt, movie_info AS mi, movie_info_idx AS mi_idx, movie_keyword AS mk, mv448
WHERE
  (
    mv448.title_id = mi_idx.movie_id
  )
  AND (
    mi_idx.movie_id = mk.movie_id
  )
  AND (
    mv448.title_id = mi.movie_id
  )
  AND (
    mi.movie_id = mk.movie_id
  )
  AND (
    mk.keyword_id = k.id
  )
  AND (
    k.keyword IN ('murder', 'murder-in-title', 'blood', 'violence')
  )
  AND (
    mv448.title_id = mk.movie_id
  )
  AND (
    mv448.title_kind_id = kt.id
  )
  AND (
    mi.info IN ('Sweden', 'Norway', 'Germany', 'Denmark', 'Swedish', 'Denish', 'Norwegian', 'German', 'USA', 'American')
  )
  AND (
    mi.info_type_id = it1.id
  )
  AND (
    it1.info = 'countries'
  )
  AND (
    mi_idx.info < '8.5'
  )
  AND (
    mi_idx.info_type_id = it2.id
  )
  AND (
    it2.info = 'rating'
  )
  AND (
    kt.kind = 'movie'
  )