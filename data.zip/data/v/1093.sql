CREATE MATERIALIZED VIEW IF NOT EXISTS mv1093 AS
SELECT
  movie_keyword.movie_id AS movie_keyword_movie_id
FROM movie_keyword, keyword
WHERE
  (
    keyword.keyword IN ('murder', 'murder-in-title', 'blood', 'violence')
  )
  AND movie_keyword.keyword_id = keyword.id