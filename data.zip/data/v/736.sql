CREATE MATERIALIZED VIEW IF NOT EXISTS mv736 AS
SELECT
  cast_info.movie_id AS cast_info_movie_id,
  cast_info.role_id AS cast_info_role_id,
  cast_info.person_role_id AS cast_info_person_role_id
FROM cast_info
WHERE
  (
    cast_info.note LIKE '%(producer)%'
  )