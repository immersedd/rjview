CREATE MATERIALIZED VIEW IF NOT EXISTS mv1200 AS
SELECT
  movie_info_idx.info AS movie_info_idx_info,
  movie_info_idx.movie_id AS movie_info_idx_movie_id
FROM info_type, movie_info_idx
WHERE
  movie_info_idx.info_type_id = info_type.id AND (
    info_type.info = 'votes'
  )