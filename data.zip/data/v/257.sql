CREATE MATERIALIZED VIEW IF NOT EXISTS mv257 AS
SELECT
  info_type.id AS info_type_id
FROM info_type
WHERE
  (
    info_type.info = 'release dates'
  )