CREATE MATERIALIZED VIEW IF NOT EXISTS mv1218 AS
SELECT
  movie_companies.movie_id AS movie_companies_movie_id,
  movie_companies.company_id AS movie_companies_company_id
FROM movie_companies
WHERE
  (
    (
      NOT movie_companies.note IS NULL
    )
    AND (
      (
        movie_companies.note LIKE '%(USA)%'
      )
      OR (
        movie_companies.note LIKE '%(worldwide)%'
      )
    )
  )