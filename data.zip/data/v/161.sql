CREATE MATERIALIZED VIEW IF NOT EXISTS mv161 AS
SELECT
  title.title AS title_title,
  keyword.keyword AS keyword_keyword,
  cast_info.person_id AS cast_info_person_id
FROM keyword, movie_keyword, cast_info, title
WHERE
  cast_info.movie_id = movie_keyword.movie_id
  AND title.id = cast_info.movie_id
  AND (
    keyword.keyword IN ('superhero', 'sequel', 'second-part', 'marvel-comics', 'based-on-comic', 'tv-special', 'fight', 'violence')
  )
  AND movie_keyword.keyword_id = keyword.id
  AND (
    title.production_year > 2000
  )
  AND title.id = movie_keyword.movie_id