CREATE MATERIALIZED VIEW IF NOT EXISTS mv448 AS
SELECT
  title.title AS title_title,
  title.production_year AS title_production_year,
  title.kind_id AS title_kind_id,
  title.id AS title_id
FROM title
WHERE
  (
    title.production_year > 2010
  )