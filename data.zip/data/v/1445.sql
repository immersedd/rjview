CREATE MATERIALIZED VIEW IF NOT EXISTS mv1445 AS
SELECT
  link_type.link AS link_type_link,
  movie_link.movie_id AS movie_link_movie_id
FROM movie_link, link_type
WHERE
  (
    link_type.link LIKE '%follow%'
  ) AND movie_link.link_type_id = link_type.id