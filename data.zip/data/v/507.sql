CREATE MATERIALIZED VIEW IF NOT EXISTS mv507 AS
SELECT
  kind_type.kind AS kind_type_kind,
  title.title AS title_title,
  title.id AS title_id
FROM comp_cast_type, complete_cast, kind_type, title
WHERE
  (
    title.production_year > 2000
  )
  AND (
    comp_cast_type.kind = 'complete+verified'
  )
  AND complete_cast.status_id = comp_cast_type.id
  AND title.id = complete_cast.movie_id
  AND (
    kind_type.kind = 'movie'
  )
  AND kind_type.id = title.kind_id