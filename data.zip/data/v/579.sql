CREATE MATERIALIZED VIEW IF NOT EXISTS mv579 AS
SELECT
  title.title AS title_title,
  movie_keyword.movie_id AS movie_keyword_movie_id,
  title.id AS title_id
FROM movie_keyword, keyword, title
WHERE
  (
    keyword.keyword = 'character-name-in-title'
  )
  AND movie_keyword.keyword_id = keyword.id
  AND title.id = movie_keyword.movie_id