CREATE MATERIALIZED VIEW IF NOT EXISTS mv1421 AS
SELECT
  complete_cast.status_id AS complete_cast_status_id,
  complete_cast.movie_id AS complete_cast_movie_id
FROM comp_cast_type, complete_cast
WHERE
  (
    comp_cast_type.kind = 'crew'
  ) AND complete_cast.subject_id = comp_cast_type.id