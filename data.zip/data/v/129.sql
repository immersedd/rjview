CREATE MATERIALIZED VIEW IF NOT EXISTS mv129 AS
SELECT
  cast_info.movie_id AS cast_info_movie_id,
  cast_info.person_id AS cast_info_person_id
FROM cast_info
WHERE
  (
    cast_info.note IN ('(writer)', '(head writer)', '(written by)', '(story)', '(story editor)')
  )