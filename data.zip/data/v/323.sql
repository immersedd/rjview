CREATE MATERIALIZED VIEW IF NOT EXISTS mv323 AS
SELECT
  company_type.id AS company_type_id
FROM company_type
WHERE
  (
    company_type.kind = 'production companies'
  )