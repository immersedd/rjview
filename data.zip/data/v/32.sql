CREATE MATERIALIZED VIEW IF NOT EXISTS mv32 AS
SELECT
  movie_keyword.movie_id AS movie_keyword_movie_id
FROM movie_keyword, keyword
WHERE
  movie_keyword.keyword_id = keyword.id
  AND (
    keyword.keyword = 'character-name-in-title'
  )