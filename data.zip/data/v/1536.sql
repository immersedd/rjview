CREATE MATERIALIZED VIEW IF NOT EXISTS mv1536 AS
SELECT
  title.title AS title_title,
  title.production_year AS title_production_year,
  title.id AS title_id
FROM title
WHERE
  (
    (
      title.production_year >= 2005
    ) AND (
      title.production_year <= 2010
    )
  )