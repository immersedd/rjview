CREATE MATERIALIZED VIEW IF NOT EXISTS mv603 AS
SELECT
  movie_info_idx.info AS movie_info_idx_info,
  movie_info_idx.info_type_id AS movie_info_idx_info_type_id,
  movie_info_idx.movie_id AS movie_info_idx_movie_id
FROM movie_info_idx
WHERE
  (
    movie_info_idx.info > '7.0'
  )