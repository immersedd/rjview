CREATE MATERIALIZED VIEW IF NOT EXISTS mv640 AS
SELECT
  link_type.link AS link_type_link,
  complete_cast.movie_id AS complete_cast_movie_id,
  movie_link.movie_id AS movie_link_movie_id,
  complete_cast.subject_id AS complete_cast_subject_id,
  complete_cast.status_id AS complete_cast_status_id
FROM movie_link, complete_cast, link_type
WHERE
  complete_cast.movie_id = movie_link.movie_id
  AND (
    link_type.link LIKE '%follow%'
  )
  AND movie_link.link_type_id = link_type.id