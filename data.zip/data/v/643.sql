CREATE MATERIALIZED VIEW IF NOT EXISTS mv643 AS
SELECT
  comp_cast_type.id AS comp_cast_type_id
FROM comp_cast_type
WHERE
  (
    comp_cast_type.kind = 'complete'
  )