CREATE MATERIALIZED VIEW IF NOT EXISTS mv530 AS
SELECT
  movie_info_idx.movie_id AS movie_info_idx_movie_id
FROM info_type, movie_info_idx
WHERE
  (
    info_type.info = 'bottom 10 rank'
  )
  AND movie_info_idx.info_type_id = info_type.id