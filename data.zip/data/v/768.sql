CREATE MATERIALIZED VIEW IF NOT EXISTS mv768 AS
SELECT
  name.name AS name_name,
  name.id AS name_id
FROM name
WHERE
  (
    (
      name.name LIKE '%An%'
    ) AND (
      name.gender = 'f'
    )
  )