CREATE MATERIALIZED VIEW IF NOT EXISTS mv1048 AS
SELECT
  movie_info.movie_id AS movie_info_movie_id,
  movie_info.info_type_id AS movie_info_info_type_id,
  movie_info.info AS movie_info_info
FROM movie_info
WHERE
  (
    (
      movie_info.note LIKE '%internet%'
    ) AND (
      movie_info.info LIKE 'USA:% 200%'
    )
  )