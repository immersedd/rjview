CREATE MATERIALIZED VIEW IF NOT EXISTS mv960 AS
SELECT
  company_name.id AS company_name_id,
  company_name.name AS company_name_name
FROM company_name
WHERE
  (
    company_name.country_code = '[us]'
  )