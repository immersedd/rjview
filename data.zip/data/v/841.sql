CREATE MATERIALIZED VIEW IF NOT EXISTS mv841 AS
SELECT
  keyword.keyword AS keyword_keyword,
  movie_keyword.movie_id AS movie_keyword_movie_id
FROM movie_keyword, keyword
WHERE
  (
    keyword.keyword IN ('superhero', 'sequel', 'second-part', 'marvel-comics', 'based-on-comic', 'tv-special', 'fight', 'violence')
  )
  AND movie_keyword.keyword_id = keyword.id