CREATE MATERIALIZED VIEW IF NOT EXISTS mv680 AS
SELECT
  info_type.id AS info_type_id
FROM info_type
WHERE
  (
    info_type.info = 'budget'
  )