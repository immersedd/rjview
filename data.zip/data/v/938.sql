CREATE MATERIALIZED VIEW IF NOT EXISTS mv938 AS
SELECT
  keyword.id AS keyword_id
FROM keyword
WHERE
  (
    keyword.keyword IN ('murder', 'murder-in-title', 'blood', 'violence')
  )